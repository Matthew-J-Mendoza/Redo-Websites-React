



export const PRheader =(Props)=>{
    return(
        <div className="text-center title mb-5 pt-1 cat-top">
            <h1>{Props.text}</h1>
        </div>
    )
}
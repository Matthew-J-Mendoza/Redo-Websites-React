


export const TpFooter = ()=>{
    return(
        <div className="text-cente footer py-4">
             <p>Tokay Press | All Rights Reserved <br/> Copyright © 2020<br/><span className="credits">a project by M&R Development</span></p>
        </div>
    )
}
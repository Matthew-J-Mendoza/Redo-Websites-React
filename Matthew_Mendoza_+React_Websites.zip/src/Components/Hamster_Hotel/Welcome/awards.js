export const AwardImg = (props) =>{
    return(
        <div>
            <img src={props.awardType} width="90%"/>
        </div>
    )
}

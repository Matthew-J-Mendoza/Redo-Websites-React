


export const IMG =(props)=>{
    return(
        <img className={props.className} src={props.src} alt={props.alt} width={props.width} height={props.height} />
    )
}